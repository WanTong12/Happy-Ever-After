const setupView = document.getElementById("setupView");
const generatingView = document.getElementById("generatingView");
const storybookView = document.getElementById("storybookView");
const homeLogo = document.getElementById("homeLogo");

const storyForm = document.getElementById("storyForm");
const promptInput = document.getElementById("prompt");
const styleSelect = document.getElementById("styleSelect");
const pageCountInput = document.getElementById("pageCount");
const ageInput = document.getElementById("age");
const generateBtn = document.getElementById("generateBtn");

const generationMessage = document.getElementById("generationMessage");
const progressBar = document.getElementById("progressBar");

const storyTitle = document.getElementById("storyTitle");
const storySummary = document.getElementById("storySummary");
const storyMetaStyle = document.getElementById("storyMetaStyle");
const storyMetaAge = document.getElementById("storyMetaAge");
const storyMetaPage = document.getElementById("storyMetaPage");

const readModePrompt = document.getElementById("readModePrompt");
const startReadAloudBtn = document.getElementById("startReadAloudBtn");
const startManualBtn = document.getElementById("startManualBtn");

const pageCard = document.getElementById("pageCard");
const pageTextTop = document.getElementById("pageTextTop");
const pageTextBottom = document.getElementById("pageTextBottom");
const pageImages = document.getElementById("pageImages");
const choiceWrap = document.getElementById("choiceWrap");

const prevPageBtn = document.getElementById("prevPageBtn");
const nextPageBtn = document.getElementById("nextPageBtn");
const restartBtn = document.getElementById("restartBtn");
const speakerBtn = document.getElementById("speakerBtn");

const tttBoard = document.getElementById("tttBoard");
const tttStatus = document.getElementById("tttStatus");
const tttReset = document.getElementById("tttReset");

const toast = document.getElementById("toast");

const state = {
  config: null,
  pollTimer: null,
  story: null,
  pagesById: new Map(),
  pageOrder: [],
  currentPageId: null,
  history: [],
  readModeChosen: false,
  readMode: "manual",
  audioEnabled: false,
  audioEl: new Audio(),
  audioCache: new Map(),
  currentlyLoadingAudioFor: null,
  ttt: {
    board: Array(9).fill(""),
    gameOver: false,
    winner: "",
    playerSymbol: "X",
    aiSymbol: "O"
  }
};

function goHome() {
  stopPolling();
  clearAudio();
  setView(setupView);
  window.scrollTo({ top: 0, behavior: "smooth" });
  generateBtn.disabled = false;
}

function setView(view) {
  setupView.classList.add("hidden");
  generatingView.classList.add("hidden");
  storybookView.classList.add("hidden");
  view.classList.remove("hidden");
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.remove("hidden");
  window.clearTimeout(showToast._timer);
  showToast._timer = window.setTimeout(() => {
    toast.classList.add("hidden");
  }, 3200);
}

function escapeHtml(text) {
  return String(text)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

async function requestJson(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {})
    }
  });

  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(payload.error || payload.message || payload.detail || "Request failed.");
  }

  return payload;
}

function setupConfig(config) {
  state.config = config;

  styleSelect.innerHTML = config.styles
    .map((style) => `<option value="${escapeHtml(style)}">${escapeHtml(style)}</option>`)
    .join("");

  ageInput.min = String(config.minAge);
  ageInput.max = String(config.maxAge);
  pageCountInput.max = String(config.maxPages);
}

async function loadConfig() {
  const config = await requestJson("/api/config");
  setupConfig(config);
}

function updateProgress(progress, message) {
  progressBar.style.width = `${Math.max(0, Math.min(100, progress))}%`;
  generationMessage.textContent = message || "Generating...";
}

function stopPolling() {
  if (state.pollTimer) {
    window.clearInterval(state.pollTimer);
    state.pollTimer = null;
  }
}

async function pollJob(jobId) {
  try {
    const payload = await requestJson(`/api/story/jobs/${jobId}`);
    updateProgress(payload.progress || 0, payload.message || "Generating...");

    if (payload.status === "failed") {
      stopPolling();
      setView(setupView);
      showToast(payload.error || "Story generation failed.");
      generateBtn.disabled = false;
      return;
    }

    if (payload.status === "completed" && payload.story) {
      stopPolling();
      generateBtn.disabled = false;
      hydrateStory(payload.story);
      return;
    }
  } catch (error) {
    stopPolling();
    generateBtn.disabled = false;
    setView(setupView);
    showToast(error instanceof Error ? error.message : "Could not check generation status.");
  }
}

function buildStoryMaps(story) {
  const pagesById = new Map();
  const pageOrder = [];

  for (const page of story.pages) {
    pagesById.set(page.id, page);
    pageOrder.push(page.id);
  }

  state.pagesById = pagesById;
  state.pageOrder = pageOrder;
}

function setSpeakerUi() {
  speakerBtn.textContent = state.audioEnabled ? "🔊" : "🔈";
  speakerBtn.classList.toggle("muted", !state.audioEnabled);
}

function clearAudio() {
  state.audioEl.pause();
  state.audioEl.currentTime = 0;
}

function updatePageMeta() {
  const index = state.pageOrder.indexOf(state.currentPageId);
  storyMetaPage.textContent = `Page ${Math.max(1, index + 1)} / ${state.pageOrder.length}`;
}

function getCurrentPage() {
  return state.pagesById.get(state.currentPageId) || null;
}

function renderChoices(page) {
  choiceWrap.innerHTML = "";

  if (!Array.isArray(page.choices) || page.choices.length !== 2) {
    return;
  }

  page.choices.forEach((choice, index) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "choice-btn";
    btn.textContent = `${index === 0 ? "Option A" : "Option B"}: ${choice.text}`;
    btn.addEventListener("click", () => {
      goToPage(choice.nextPageId, true);
    });
    choiceWrap.appendChild(btn);
  });
}

function renderPage() {
  const page = getCurrentPage();
  if (!page) return;

  pageTextTop.classList.add("hidden");
  pageTextBottom.classList.add("hidden");

  if (page.textPosition === "top") {
    pageTextTop.textContent = page.text;
    pageTextTop.classList.remove("hidden");
    pageTextBottom.textContent = "";
  } else {
    pageTextBottom.textContent = page.text;
    pageTextBottom.classList.remove("hidden");
    pageTextTop.textContent = "";
  }

  pageImages.innerHTML = "";
  const images = Array.isArray(page.imageUrls) ? page.imageUrls.slice(0, 3) : [];
  pageImages.dataset.count = String(images.length);

  for (const imageUrl of images) {
    const frame = document.createElement("figure");
    frame.className = "story-image-frame";

    const image = document.createElement("img");
    image.className = "story-image";
    image.src = imageUrl;
    image.alt = `Illustration for ${state.story.title}`;
    image.loading = "lazy";
    image.decoding = "async";

    frame.appendChild(image);
    pageImages.appendChild(frame);
  }

  renderChoices(page);
  updatePageMeta();
  updateNavButtons();

  if (state.audioEnabled && state.readModeChosen) {
    playNarrationForCurrentPage().catch((error) => {
      showToast(error instanceof Error ? error.message : "Audio could not be played.");
    });
  } else {
    clearAudio();
  }
}

function updateNavButtons() {
  prevPageBtn.disabled = state.history.length <= 1;

  const page = getCurrentPage();
  if (!page) {
    nextPageBtn.disabled = true;
    return;
  }

  if (Array.isArray(page.choices) && page.choices.length === 2) {
    nextPageBtn.disabled = true;
    nextPageBtn.title = "Choose Option A or B to continue.";
    return;
  }

  nextPageBtn.title = "";
  const index = state.pageOrder.indexOf(page.id);
  nextPageBtn.disabled = index === -1 || index >= state.pageOrder.length - 1;
}

function goToPage(pageId, pushToHistory = true) {
  if (!state.pagesById.has(pageId)) {
    showToast("That page could not be found.");
    return;
  }

  state.currentPageId = pageId;
  if (pushToHistory) {
    state.history.push(pageId);
  }

  renderPage();
}

function goToPreviousPage() {
  if (state.history.length <= 1) return;

  state.history.pop();
  const previous = state.history[state.history.length - 1];
  state.currentPageId = previous;
  renderPage();
}

function goToNextLinearPage() {
  const current = getCurrentPage();
  if (!current) return;

  const index = state.pageOrder.indexOf(current.id);
  const nextId = state.pageOrder[index + 1];
  if (!nextId) {
    showToast("You reached the end of this path.");
    return;
  }

  goToPage(nextId, true);
}

async function fetchNarrationAudio(page) {
  const cacheKey = `${state.story.id}:${page.id}`;
  if (state.audioCache.has(cacheKey)) {
    return state.audioCache.get(cacheKey);
  }

  state.currentlyLoadingAudioFor = cacheKey;
  const payload = await requestJson("/api/story/audio", {
    method: "POST",
    body: JSON.stringify({
      storyId: state.story.id,
      pageId: page.id,
      text: page.text
    })
  });

  state.currentlyLoadingAudioFor = null;
  state.audioCache.set(cacheKey, payload.audioUrl);
  return payload.audioUrl;
}

async function playNarrationForCurrentPage() {
  const page = getCurrentPage();
  if (!page || !state.audioEnabled) return;

  const activePageId = page.id;
  const audioUrl = await fetchNarrationAudio(page);

  if (!state.audioEnabled || state.currentPageId !== activePageId) {
    return;
  }

  state.audioEl.pause();
  state.audioEl.src = audioUrl;
  state.audioEl.currentTime = 0;

  try {
    await state.audioEl.play();
  } catch {
    showToast("Tap the speaker again to allow audio playback.");
  }
}

function setReadMode(mode) {
  state.readMode = mode;
  state.readModeChosen = true;

  if (mode === "aloud") {
    state.audioEnabled = true;
  }

  readModePrompt.classList.add("hidden");
  setSpeakerUi();
  renderPage();
}

function hydrateStory(story) {
  state.story = story;
  state.audioCache.clear();
  clearAudio();

  buildStoryMaps(story);

  storyTitle.textContent = story.title;
  storySummary.textContent = story.summary || "";
  storyMetaStyle.textContent = story.style;
  storyMetaAge.textContent = `Age ${story.age}`;

  state.currentPageId = story.startPageId;
  state.history = [story.startPageId];
  state.readModeChosen = false;
  state.readMode = "manual";
  state.audioEnabled = false;
  setSpeakerUi();

  readModePrompt.classList.remove("hidden");
  renderPage();
  setView(storybookView);
}

function resetStoryToStart() {
  if (!state.story) return;

  state.history = [state.story.startPageId];
  state.currentPageId = state.story.startPageId;
  renderPage();
}

function evaluateBoard(board) {
  const wins = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
  ];

  for (const [a, b, c] of wins) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return board[a];
    }
  }

  if (board.every(Boolean)) return "draw";
  return "";
}

function chooseEasyAiMove(board) {
  const empties = board
    .map((value, idx) => (value ? null : idx))
    .filter((idx) => idx != null);

  if (empties.length === 0) return null;

  const shouldTrySmart = Math.random() < 0.35;
  if (!shouldTrySmart) {
    return empties[Math.floor(Math.random() * empties.length)];
  }

  const tryWinning = (symbol) => {
    for (const idx of empties) {
      const copy = [...board];
      copy[idx] = symbol;
      if (evaluateBoard(copy) === symbol) return idx;
    }
    return null;
  };

  return (
    tryWinning(state.ttt.aiSymbol) ??
    tryWinning(state.ttt.playerSymbol) ??
    empties[Math.floor(Math.random() * empties.length)]
  );
}

function renderTttBoard() {
  tttBoard.innerHTML = "";

  state.ttt.board.forEach((value, index) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "ttt-cell";
    btn.textContent = value;
    btn.disabled = Boolean(value) || state.ttt.gameOver;

    btn.addEventListener("click", () => {
      handleTttPlayerMove(index);
    });

    tttBoard.appendChild(btn);
  });
}

function updateTttStatus() {
  if (state.ttt.gameOver) {
    if (state.ttt.winner === "draw") {
      tttStatus.textContent = "It's a draw!";
    } else if (state.ttt.winner === state.ttt.playerSymbol) {
      tttStatus.textContent = "You win!";
    } else {
      tttStatus.textContent = "Computer wins!";
    }
    return;
  }

  tttStatus.textContent = "Your turn (X)";
}

function resetTtt() {
  state.ttt.board = Array(9).fill("");
  state.ttt.gameOver = false;
  state.ttt.winner = "";
  renderTttBoard();
  updateTttStatus();
}

function handleTttPlayerMove(index) {
  if (state.ttt.gameOver || state.ttt.board[index]) return;

  state.ttt.board[index] = state.ttt.playerSymbol;
  let winner = evaluateBoard(state.ttt.board);

  if (winner) {
    state.ttt.gameOver = true;
    state.ttt.winner = winner;
    renderTttBoard();
    updateTttStatus();
    return;
  }

  const aiMove = chooseEasyAiMove(state.ttt.board);
  if (aiMove != null) {
    state.ttt.board[aiMove] = state.ttt.aiSymbol;
  }

  winner = evaluateBoard(state.ttt.board);
  if (winner) {
    state.ttt.gameOver = true;
    state.ttt.winner = winner;
  }

  renderTttBoard();
  updateTttStatus();
}

async function handleGenerateSubmit(event) {
  event.preventDefault();

  const pageCount = Number(pageCountInput.value);
  const age = Number(ageInput.value);

  if (!state.config) return;

  if (pageCount < 3 || pageCount > state.config.maxPages) {
    showToast(`Page count must be between 3 and ${state.config.maxPages}.`);
    return;
  }

  if (age < state.config.minAge || age > state.config.maxAge) {
    showToast(`Age must be between ${state.config.minAge} and ${state.config.maxAge}.`);
    return;
  }

  const payload = {
    prompt: promptInput.value.trim(),
    style: styleSelect.value,
    pageCount,
    age
  };

  if (payload.prompt.length < 8) {
    showToast("Please enter a longer story idea.");
    return;
  }

  generateBtn.disabled = true;
  updateProgress(0, "Submitting your story request...");
  setView(generatingView);
  resetTtt();

  try {
    const data = await requestJson("/api/story/jobs", {
      method: "POST",
      body: JSON.stringify(payload)
    });

    stopPolling();
    await pollJob(data.jobId);
    state.pollTimer = window.setInterval(() => {
      pollJob(data.jobId);
    }, 2000);
  } catch (error) {
    generateBtn.disabled = false;
    setView(setupView);
    showToast(error instanceof Error ? error.message : "Could not start generation.");
  }
}

function bindEvents() {
  storyForm.addEventListener("submit", handleGenerateSubmit);

  if (homeLogo) {
    homeLogo.addEventListener("click", goHome);
  }

  startReadAloudBtn.addEventListener("click", () => setReadMode("aloud"));
  startManualBtn.addEventListener("click", () => setReadMode("manual"));

  prevPageBtn.addEventListener("click", goToPreviousPage);
  nextPageBtn.addEventListener("click", goToNextLinearPage);
  restartBtn.addEventListener("click", resetStoryToStart);

  speakerBtn.addEventListener("click", () => {
    state.audioEnabled = !state.audioEnabled;
    setSpeakerUi();

    if (state.audioEnabled) {
      state.readModeChosen = true;
      playNarrationForCurrentPage().catch((error) => {
        showToast(error instanceof Error ? error.message : "Unable to play narration.");
      });
    } else {
      clearAudio();
    }
  });

  tttReset.addEventListener("click", resetTtt);

  state.audioEl.addEventListener("ended", () => {
    // Intentionally empty; narration will follow on page flips.
  });
}

async function init() {
  try {
    bindEvents();
    resetTtt();
    await loadConfig();
    setView(setupView);
  } catch (error) {
    showToast(error instanceof Error ? error.message : "App failed to initialize.");
  }
}

init();
